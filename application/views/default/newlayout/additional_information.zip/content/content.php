<div class="main">
<div class="incon">

<div class="mconleft">
        
<ul class="padli10">
	<li>        
        <div id="s1post">About</div>
        
        <p class="LH18">nonafy is an online and mobile marketplace that allows folks to live a smarter and more fulfilling life by once again relying on their neighbors. nonafy is about solving an age-old problem: there is never enough time in the day to do everything you need to do. At nonafy, we harness the power of the community to get things done - forming a virtual neighborhood. We call it "Service Networking" - leveraging the latest social, mobile and location-based technologies to bring neighbors together to get things done. </p>
	</li>
    <li>
        <p class="LH18">nonafy is an online and mobile marketplace that allows folks to live a smarter and more fulfilling life by once again relying on their neighbors. nonafy is about solving an age-old problem: there is never enough time in the day to do everything you need to do. At nonafy, we harness the power of the community to get things done - forming a virtual neighborhood. We call it "Service Networking" - leveraging the latest social, mobile and location-based technologies to bring neighbors together to get things done. </p>
    </li>
</ul>        
                
		</div>    	
 


<?php //echo $this->load->view($theme.'/layout/ntask/points_sidebar'); ?>

<div class="mconright">

				<div class="estim marB10">Title</div>
				<ul class="accr">
                	<li><a href="#">Jobs</a></li>
                	<li><a href="#">Recurring Jobs</a></li>
                	<li><a href="#">Scheduled Jobs</a></li>
                	<li><a href="#">Favourite TaskRabo</a></li>
                	<li><a href="#">Locations</a></li>
				</ul>
</div>

        
        
        	
            
            
            
            
            
            
        
        <div class="clear"></div>



    </div>
</div>