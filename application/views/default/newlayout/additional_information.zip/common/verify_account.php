<!--banner start-->
<div id="acc-banners-ph" class="banner-contain"></div>
<!--banner ends-->
<div>
<div>
 <div class="red-subtitle">Email verifikation</div>
    	<div id="two-columnar-section" class="top-cont-main-dash">
        <div class="task-layout">
        <div class="db-rightinfo" style="width:100%; margin:0px 0 0 0">
        <div class="home-signpost-content">


<?php if($status=='success') { ?>

<strong>
<p style="color:#F30; text-align:center; padding:20px 0 0 0; font-weight:normal; font-size:28px;">Congrats !!!!</p>  
<p style="color:#F30; text-align:center; padding:20px 0 0 0;">You have successfully verified your email .</p>  
<p style="color:#F30; text-align:center; padding:3px 0 30px 0;">Log in to your account and start Posting the Task.</p>  
</strong>

<?php } else { ?> 
<strong>
<p style="color:#F30; text-align:center; padding:20px 0;">Email verifikationen har misslyckats. Detta kan bero på fel konfirmationskod. Vänligen försök igen</p>
</strong>
<?php } ?>



</div></div></div></div>

