<div class="body_cont">
        	<div>
				<!--banner-->
                <div id="acc-banners-ph" class="banner-contain">
                </div>
				<!--banner ends-->
                
			</div>	
        </div>
	</div>
    <div id="find-placing" class="find-trust trust-safety">
        <div class="red-subtitle top-red-subtitle">Kontakta oss</div>
        <div class="profile_back">
        	<div class="container">
            	<div class="db-rightinfo db-rightinfo-inner" style="width:100%; margin:0px 0 0 0; padding:20px; min-height:330px;">
                    <ul class="three-columnar">
                        <li class="left" style="width:46%">
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeIn;">
                                <h2 class="how-business" style="margin:0; float:left; width:100%; text-align:left; font-size:18px; font-weight:normal;"><b>Bolag: </b> Entowork AB, ORG.NR: 559029-6850, LUND. SE</h2>
                                <div class="blogger-comment" style="text-align:left; margin-top:10px;"><b>Email :</b> kundtjanst@entowork.se</div>
                                <div class="blogger-comment" style="text-align:left; margin-top:10px;"><b>Företagskontakt: </b> foretag@entowork.se</div>
                            </div>
                        </li>
                        
                    </ul>
            	</div>
            </div>
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
    </div>
    
    