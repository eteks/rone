<!--banner start-->
<div id="acc-banners-ph" class="banner-contain"></div>
<!--banner ends-->
<div>
<div>
 <div class="red-subtitle top-red-subtitle">Tack!</div>
    	<div class="profile_back">
        <div class="container">
        <div class="db-rightinfo db-rightinfo-inner" style="width:100%; margin:0px 0 0 0">
        <div class="home-signpost-content" style="min-height:400px;">


<?php if($msg=='sign_up') { ?>

<strong>
<p style="color:#F30; font-size:25px; text-align:center; padding:150px 0 0 0;">You have successfully signed up. Please verify your email address.</p>
<p style="color:#F30; font-size:19px; text-align:center; font-weight:normal; padding:10px 0 30px 0;">Observera: Kolla även i din skräppost, ifall det hamnat fel! </p>
</strong>

<?php } else { ?> 
<strong>
<p style="color:#F30; text-align:center;">Tidsgränsen har uppnåtts, försök igen.</p>
</strong>
<?php } ?>



</div>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>