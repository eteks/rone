<div class="body_cont">
        	<div>
				
                <div id="acc-banners-ph" class="banner-contain">
                	<div class="banner-area-for-work">
                    	<a href="#"><img src="<?php echo base_url().getThemeName(); ?>/images/banner-business.jpg" alt="" /></a>
                    </div>
                </div>
                
                <!--<div class="post-today">
                	<div class="red-subtitle">How Entowork Works</div>
                    <div id="how-content">
                        <div class="container">
                            <div class="inside inside-works">
                                <div class="span3 wow fadeIn animated call animated" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;">
                                <p>Tell Us What You need to be done</p>
                                </div>
                                <div class="span3 wow fadeIn animated arrow animated" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;"></div>
                                <div class="span3 wow fadeIn animated taskers animated" data-wow-delay="0.7s" style="visibility: visible; animation-delay: 0.7s; animation-name: fadeIn;"><p>Receive offers from trusted taskers in your area</p></div>
                                <div class="span3 wow fadeIn animated arrow animated" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeIn;"></div>
                                <div class="span3 wow fadeIn animated right-choice animated" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeIn;"><p>Choose the best tasker for the job</p></div>
                            </div>
                        </div>
         			</div>
                </div>-->
			</div>	
        </div>
	</div>
    <div class="profile_back">
        <div class="container">
            <div id="find-placing" class="find-trust trust-safety" style="margin-top:15px;">
                <div class="red-subtitle top-red-subtitle">Why Entowork Business</div>
                <div class="container white-inner">
                    <ul class="three-columnar three-columnar-get">
                        <li class="left one-part" style="width:46%">
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeIn;">
                                <img border="0" style="margin:15px 0 25px 0; width:94px;" src="<?php echo base_url().getThemeName(); ?>/images/time_icon_1.png">
                                <h2 class="how-business" style="margin:0; float:left; width:100%; text-align:center; font-size:24px">Time</h2>
                                <div class="blogger-comment">Our seamless user experience instantly connects your business with a wide range of workers. Have a big job on your hands? Entowork business will find the Taskers needed to get the job done as effiecntely as possible. Your time is valuable. Get started now.</div>
                            </div>
                        </li>
                        <li class="right one-part" style="width:46%">
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeIn;">
                                <img border="0" style="margin:15px 0 25px 0" src="<?php echo base_url().getThemeName(); ?>/images/payment.png">
                                <h2 class="how-business" style="margin:0; float:left; width:100%; text-align:center; font-size:24px">Money</h2>
                                <div class="blogger-comment">As a South African business you can save money by posting your daily tasks on our platform. By setting your own price, you'll be able to find the best possible candidate on your budget. Only assign the Taskers you are 100% happy with.</div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="post-today">
                <div class="red-subtitle top-red-subtitle">Trending on Entowork Business</div>
                <div id="how-content">
                    <div class="container inside-ask-for-work">
                        <ul class="three-columnar ask-for-work get-business">
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn;">
                                <li class="left">
                                    <div class="links-info">
                                        <h1>Marketing</h1>
                                        <h4>Flyer distribution</h4>
                                        <h4>Marketing promotions</h4>
                                        <h4>facebook advertising</h4>
                                        <h4>postering and stickering</h4>
                                    </div>
                                </li>
                            </div>
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeIn;">
                                <li class="center">
                                    <div class="links-info">
                                        <h1>Web Development</h1>
                                        <h4>Web design & development</h4>
                                        <h4>Mobile app design & development</h4>
                                        <h4>bug fixing</h4>
                                        <h4>blogs & content creating</h4>
                                    </div>
                                </li>
                            </div>
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeIn;">
                                <li class="right">
                                    <div class="links-info">
                                        <h1>office help</h1>
                                        <h4>admin assistance</h4>
                                        <h4>filing work</h4>
                                        <h4>data entry</h4>
                                        <h4>delivery help</h4>
                                    </div>
                                </li>
                            </div>
                        </ul>
                        <ul class="three-columnar get-business">
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="0.8s" style="visibility: visible; animation-delay: 0.8s; animation-name: fadeIn;">
                                <li class="left">
                                    <div class="links-info">
                                        <h1>research</h1>
                                        <h4>focus group respondent</h4>
                                        <h4>product testing</h4>
                                        <h4>beta testing</h4>
                                        <h4>UX testing</h4>
                                    </div>
                                </li>
                            </div>
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeIn;">
                                <li class="center">
                                    <div class="links-info">
                                        <h1>editing & design</h1>
                                        <h4>photo & video editing</h4>
                                        <h4>brochure & flyer design</h4>
                                        <h4>logo design</h4>
                                        <h4>business card design</h4>
                                    </div>
                                </li>
                            </div>
                            <div class="span6 wow fadeIn animated  animated" data-wow-delay="1.2s" style="visibility: visible; animation-delay: 1.2s; animation-name: fadeIn;">
                                <li class="right">
                                    <div class="links-info">
                                        <h1>events</h1>
                                        <h4>runners</h4>
                                        <h4>photographers</h4>
                                        <h4>general assistance</h4>
                                        <h4>promotional models</h4>
                                    </div>
                                </li>
                            </div>
                        </ul>
                    </div>
                </div>
            </div>
            <script type='text/javascript'>
               /* jQuery(document).ready(function(){
                    jQuery( "#task_state_id" ).change(function() {
                    var task_state_id = $('#task_state_id').val(); 
                    alert(task_state_id);
                    list1 = '<option value="">Select City</option>';
                    jQuery('#task_city_id').html(list1);
                        jQuery.ajax({
                            type:'POST',
                            url:'<?php echo base_url(); ?>" + "index.php/task/task_city',
                            data:{'state_id':task_state_id},
                            success:function(list){
                                if(list.search(/\S/)!=-1){
                                    list1 = '<option value="">Select City</option>'+list;
                                    jQuery('#task_city_id').html(list1);
                                    }
                                }
                        });
                    });
                });*/
        
        function sub_contact()
        {
        
                if($('#company_name').val()=="")
                {
                    alert('Please enter your company name');
                    return false;
                }
                if($('#contact_name').val()=="")
                {
                    alert('Please enter your contact name');
                    return false;
                }
                if($('#contact_email').val()=="")
                {
                    alert('Please enter your email');
                    return false;
                }
                var email=$('#contact_email').val();
                var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                if(!email.match(mailformat))
                { 
                    alert("You have entered an invalid email address!");
                    return false;
                }
        
                jQuery.ajax({
                            type:'POST',
                            url:'http://Entowork.co.za/home/business_con/',
                            data:{
                                company_name: $('#company_name').val(),
                                contact_name : $('#contact_name').val(),
                                contact_number : $('#contact_number').val(),
                                contact_email :$('#contact_email').val()
                            },
                            success:function(results){ 
                            $('#mess').text('Thank you for submitting your details.A member of the Entowork team will be in contact with you soon.');
                            $('#company_name').val('');
                            $('#contact_name').val('');
                            $('#contact_number').val('');
                            $('#contact_email').val('');
                            }
                        });
        
        
        }
        
        </script>
            <div class="clear"></div>
            <div class="span6 wow fadeIn animated  animated" data-wow-delay="0.5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeIn;">
                <div class="db-rightinfo signup-box-main signup-box-main-inner getting-form">
                    <div class="home-signpost-content"> 
                        <h1 class="social-login-title"><b>Getting Started</b></h1>
                        <div class="form-main-box">
                            <div id="mess"></div>
                            <form class="form_design" id="signupForm" name="signupForm" accept-charset="utf-8" method="post" action="">                               
                                <fieldset>
                                    <table width="98.6%" cellspacing="0" cellpadding="5" border="0" class="fl">
                                        <tbody>
                                            <tr id="full_nameTR">
                                                <td align="center">
                                                    <input type="text" class="ntext form-control form-control-signup new_form icon-back6" placeholder="Company Name *" id="company_name" name="company_name">
                                                </td>
                                            </tr>
                                            <tr id="zip_codeTR">
                                                <td align="center">
                                                    <input type="text" class="ntext form-control form-control-signup new_form icon-back2" id="contact_name" placeholder="Contact Name *" name="contact_name">
                                                </td>
                                            </tr>
                                            <tr id="mobile_noTR">
                                                <td align="center">
                                                    <input type="text" class="ntext form-control form-control-signup new_form icon-back3" id="contact_number" placeholder="Contact Number" name="contact_number">
                                                </td>
                                            </tr>
                                            <tr id="emailTR">
                                                <td align="center">
                                                    <input type="text" class="ntext form-control form-control-signup new_form icon-back4" placeholder="Contact Email *" id="contact_email" name="contact_email">
                                                </td>
                                            </tr>
                                            <tr>
                                                <td lign="center" style="text-align:center;">
                                                    <input type="button" value="Submit" class=" btn btn-default btn-default-info" name="submit" id="submit"  onclick="return sub_contact();">  
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </fieldset>
                            </form>
                        </div>    
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div style="height:55px;"></div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
        </div>
    </div>