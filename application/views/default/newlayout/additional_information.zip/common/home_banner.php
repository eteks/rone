<div class="main">	
<script type="application/javascript">
  jQuery(function($) {
  
   $("#scomsonbg1").mouseover(function () {
    $("#comsonbg1").show("fast");
    });

	$("#scomsonbg1").mouseout(function () {
    $("#comsonbg1").hide("fast");
    });
	
   $("#scomsonbg2").mouseover(function () {
    $("#comsonbg2").show("fast");
    });

	$("#scomsonbg2").mouseout(function () {
    $("#comsonbg2").hide("fast");
    });
	
   $("#scomsonbg3").mouseover(function () {
    $("#comsonbg3").show("fast");
    });

	$("#scomsonbg3").mouseout(function () {
    $("#comsonbg3").hide("fast");
    });

   $("#scomsonbg4").mouseover(function () {
    $("#comsonbg4").show("fast");
    });

	$("#scomsonbg4").mouseout(function () {
    $("#comsonbg4").hide("fast");
    });

   $("#scomsonbg5").mouseover(function () {
    $("#comsonbg5").show("fast");
    });

	$("#scomsonbg5").mouseout(function () {
    $("#comsonbg5").hide("fast");
    });

   $("#scomsonbg6").mouseover(function () {
    $("#comsonbg6").show("fast");
    });

	$("#scomsonbg6").mouseout(function () {
    $("#comsonbg6").hide("fast");
    });

});	
	</script>
<ul class="youmap">
	<li>
    	<iframe width="533" height="316" src="http://www.youtube.com/embed/OuP7YCEoL60" frameborder="0"  allowTransparency="true" style="z-index:0" allowfullscreen></iframe>
        
        
        
        
    </li>
	<li class="posrel">
        <img src="<?php echo base_url().getThemeName();?>/images/mapnew.png" alt="" usemap="#planetmap" width="409" height="346"/>


<?php /*?>
        
<map name="planetmap">

<area shape="circle" coords="33,143,22" id="scomsonbg1" title="" alt="Victoria"/>
<div id="comsonbg1"></div>

<area shape="circle" coords="143,189,22" id="scomsonbg2" title="" alt="Toronto" href="#" />
<div id="comsonbg2"></div>

<area shape="circle" coords="187,170,22" id="scomsonbg3" title="" alt="Montreal" href="#" />
<div id="comsonbg3"></div>

<area shape="circle" coords="234,280,22" id="scomsonbg4" title="" alt="Los Angeles" href="google.com" />
<div id="comsonbg4"></div>

<area shape="circle" coords="350,244,22" id="scomsonbg5" title="" alt="Chicago" href="#" />
<div id="comsonbg5"></div>

<area shape="circle" coords="407,233,22" id="scomsonbg6" title="" alt="New York" href="#"/>
<div id="comsonbg6"></div>

<area shape="rect" coords="70,180,20,170" alt="Victoria" href="#" />
<area shape="rect" coords="170,225,120,215" alt="Toronto" href="#" />
<area shape="rect" coords="230,210,175,200" alt="Montreal" href="#" />
<area shape="rect" coords="290,327,220,317" alt="Los Angeles" href="#" />
<area shape="rect" coords="380,290,335,280" alt="Chicago" href="#" />
<area shape="rect" coords="444,275,390,265" alt="New York" href="#" />

</map>

<?php */?>
    
    </li>
    <div class="clear"></div>
</ul>
<div class="clear"></div>
<div class="watch">Watch our 200,000+ views video</div> 
    </div>
    
    
    
    