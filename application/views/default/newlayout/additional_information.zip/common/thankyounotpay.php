<!--banner start-->
<div id="acc-banners-ph" class="banner-contain"></div>
<!--banner ends-->
<div>
<div>
 <div class="red-subtitle top-red-subtitle">Betalningen misslyckades.</div>
    	<div class="profile_back">
        <div class="container">
        <div class="db-rightinfo db-rightinfo-inner" style="width:100%; margin:0px 0 0 0">
        <div class="home-signpost-content" style="min-height:400px;">

<strong>
<p style="color:#F30; text-align:center;"> Oops!!!  Din transaktion misslyckades, vänligen försök igen. </p>
</strong>



</div>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>