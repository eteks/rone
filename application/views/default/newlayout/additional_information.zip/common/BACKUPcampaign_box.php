<div class="box_cont">
           	<div class="box">
            	<div class="box_heading">
                	<div class="box_img"><img src="<?php echo base_url().getThemeName(); ?>/images/ico_mid_one.png"></div>
                    <h1 class="box_h">Hive Owners</h1>
                </div><!--box heading ends-->
                <p>This is a simple and easy way to get your tasks done quickly. Just post your tasks, see responses and select a Bee to carry out the work. Easy </p>
            </div><!--box ends-->
            <div class="box">
            	<div class="box_heading">
                	<div class="box_img"><img src="<?php echo base_url().getThemeName(); ?>/images/ico_mid_two.png"></div>
                    <h1 class="box_h">Boost <br>your results</h1>
                </div><!--box heading ends-->
                <p>Getting your tasks carried out is the be all and end all. Bumblebeeme lets you post and manage your tasks when and how you want.</p>
            </div><!--box ends-->
            <div class="box background_none" style="padding:10px">
            	<div class="box_heading">
                	<div class="box_img"><img src="<?php echo base_url().getThemeName(); ?>/images/ico_mid_three.png"></div>
                    <h1 class="box_h">User friendly<br>and effective</h1>
                </div><!--box heading ends-->
                <p>This is a safe and efficient platform for connecting Worker Bees to Hive Owners.</p>
            </div><!--box ends-->
</div>



