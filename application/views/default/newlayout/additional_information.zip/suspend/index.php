<script type="text/javascript" src="<?php echo base_url().getThemeName(); ?>/js/lib/tooltip2.js"></script>
          	
<!--banner start-->
<div id="acc-banners-ph" class="banner-contain"></div>
<!--banner ends-->
<div>
<div>
 <div class="red-subtitle top-red-subtitle">Account suspend</div>
    	<div class="profile_back">
        <div class="container">
        <div class="db-rightinfo db-rightinfo-inner" style="width:100%; margin:0px 0 0 0">
        <div class="home-signpost-content" style="min-height:400px;">


<strong>
<p style="color:#F30; font-size:20px; text-align:center; padding:180px 0 0 0;">Your account has been suspended , Please contact to support for further details</p>
</strong>


</div>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>