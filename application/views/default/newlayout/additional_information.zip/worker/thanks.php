<!--banner start-->
<div id="acc-banners-ph" class="banner-contain"></div>
<!--banner ends-->
<div class="red-subtitle top-red-subtitle">Thanks</div>
    	<div class="profile_back">
        <div class="container">
        <div class="db-rightinfo db-rightinfo-inner" style="width:100%; margin:0px 0 0 0;">
        <div class="home-signpost-content" style="min-height:330px;">
<div class=""><strong><?php /* 

$site_setting=site_setting();


if($error != '') { ?> <div class="errmsgcl" style="margin-top:10px;"><strong><?php echo $error; ?></div></strong> <?php } */ ?></strong>
<div class="incon">
    	<div style="text-align:center;" class="mconleft borno borno-159">
		    <div style="color:#881926 ; font-size:24px; margin:90px 0 15px 0px;" id="s1post">Congrats!!!! You have successfully applied for Helper</div>
            <p style="font-size:19px; padding-bottom:17px;">
            	A member of the Entowork team will review your application and get back to you shortly.
            </p>
            <p style="font-size:17px;">
            	<strong>Please note:</strong> Applicants with photos and good information in their Entowork profiles will be given highest priority, so if it's still not done go to your account and fill the information
            </p>
		</div>
        <div class="clear"></div>
    </div>
</div>
    </div>
    <div class="clear"></div>
</div>
<div class="clear"></div>