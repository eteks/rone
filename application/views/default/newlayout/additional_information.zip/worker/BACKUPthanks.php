<div class="red-subtitle" style="margin:172px 0 0 0">Thanks</div>
    	<div id="two-columnar-section">
        <div class="task-layout">
        <div class="db-rightinfo" style="width:100%; margin:25px 0 0 0">
        <div class="home-signpost-content">
<section>
<div class="main"><strong><?php 

$site_setting=site_setting();


if($error != '') { ?> <div class="errmsgcl" style="margin-top:10px;"><strong><?php echo $error; ?></div></strong> <?php } ?></strong>
<div class="incon">
    	<div class="mconleft borno" >
			
<div id="s1post">Thanks for applying!</div>

<ul class="thapp">

<li>A member of the <?php echo $site_setting->site_name; ?> team will review your application through the process. </li>


	<li>
    	<h3 class="col">BACKGROUND CHECK</h3>
        <p class="LH18">After your application approved, watch your inbox for another email containing instructions on how to submit your background check.</p>
    </li>
  
   <!-- <li>Thanks for applying, and we look forward to hearing what you have to say!</li>-->
    
   
    <li><h3 class="col marB5">WE HIGHLY RECOMMEND</h3>
    <p class="LH18">If you have not done so already, please go to your <?php echo $site_setting->site_name; ?> account profile to upload a photo and fill in your "About Me" section with as much relevant information as possible. </p>
    </li>
    <li>Applicants with photos and good information in their <?php echo $site_setting->site_name; ?> profiles will be given highest priority. </li>
</ul>

                
		</div>
        <div class="mconright">
        </div>
        <div class="clear"></div>



    </div>
</div>



</section>
    </div>
</div>